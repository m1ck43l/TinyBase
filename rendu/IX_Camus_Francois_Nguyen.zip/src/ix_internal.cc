/*
 * ixinternal.cc
 *
 *  Created on: Jan 20, 2012
 *      Author: mickael
 */

#include "ix_internal.h"
#include <cstring>
#include <cstdlib>

IX_Internal::IX_Internal(int _tailleCle, int _taillePtr) {
	tailleCle = _tailleCle;
	taillePtr = _taillePtr;
}

IX_Internal::~IX_Internal() {
	// TODO Auto-generated destructor stub
}

PageNum IX_Internal::GetPtr(PF_PageHandle &pf_ph, int pos) {

    RC rc;
    char *pData;
    PageNum num;

    rc = pf_ph.GetData(pData);
    if (rc) IX_PrintError(rc);

    pData += (sizeof(IX_NoeudHeader) + (pos-1)*(tailleCle + taillePtr));

    memcpy(&num, pData, sizeof(PageNum));

    return num;
}

void* IX_Internal::GetCle(PF_PageHandle &pf_ph, int pos) {

    RC rc;
    char *pData;
    void *pData2 = malloc(tailleCle);

    rc = pf_ph.GetData(pData);
    if (rc) IX_PrintError(rc);

    pData += (sizeof(IX_NoeudHeader) + pos*taillePtr + (pos-1)*tailleCle);

    memcpy(pData2, pData, tailleCle);

    return pData2;
}
