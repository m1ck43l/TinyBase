/*
 * ixinternal.h
 *
 *  Created on: Jan 20, 2012
 *      Author: mickael
 */

#ifndef IXINTERNAL_H_
#define IXINTERNAL_H_

#include "pf.h"

//
// IX_FileHeader
//
typedef struct ix_fileheader {
    int tailleCle;
    int taillePtr;
    PageNum numRacine;
    AttrType type;
} IX_FileHeader;

//
// IX_NoeudHeader
//
typedef struct ix_noeudHeader {
    int niveau; // Niveau sert à savoir si l'on est une feuille ou un noeud interne, niveau=0 correspond à une feuille
    int nbMaxPtr;  //Nombre maximum de pointeurs dans le noeud, il y aura donc nbMaxPtr-1 clés au max dans le noeud
    int nbCle;//Nombre de clé actuellement dans le noeud (il y a donc nbCle+2 pointeurs)
    PageNum pageMere;
    PageNum prevPage;
    PageNum nextPage;

} IX_NoeudHeader;

//
// IX_BucketHeader
//
typedef struct ix_bucketheader {
    // Nombre actuel de RID dans le bucket
    int nbRid;
    // Nombre maximal de RIC pouvant être stockés dans le bucket
    int nbMax;
    PageNum nextBuck;
} IX_BucketHeader;

void IX_PrintError(RC rc);

class IX_Internal {
public:
	IX_Internal(int tailleCle, int taillePtr);
	virtual ~IX_Internal();

	PageNum GetPtr(PF_PageHandle &pf_ph, int pos);
	void* GetCle(PF_PageHandle &pf_ph, int pos);

private:
	int tailleCle;
	int taillePtr;
};

#endif /* IXINTERNAL_H_ */
